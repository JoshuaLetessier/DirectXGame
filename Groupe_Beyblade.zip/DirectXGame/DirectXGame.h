#pragma once

#include "resource.h"

#include "GlobalScript.h"

GlobalScript* globalScript = new GlobalScript();