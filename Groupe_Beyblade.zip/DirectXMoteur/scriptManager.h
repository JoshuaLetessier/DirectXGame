#pragma once
#include "Script.h"
#include <vector>
using namespace std;

class scriptManager
{
public:
	scriptManager();
	~scriptManager();

	

	vector<Script*> scriptList;

};

