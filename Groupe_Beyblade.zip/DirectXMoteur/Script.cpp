#include "Script.h"

Script::Script()
{
}

Script::~Script()
{
	scriptList.clear();
}
