#include "scriptManager.h"

scriptManager::scriptManager()
{
}

scriptManager::~scriptManager() {};

